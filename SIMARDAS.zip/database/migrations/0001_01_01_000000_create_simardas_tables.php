<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Tabel User (custom untuk SIMARDAS)
        Schema::create('user', function (Blueprint $table) {
            $table->id('id_user');
            $table->string('nama');
            $table->string('username')->unique();
            $table->string('email')->unique();
            $table->string('password');
            $table->enum('role', ['Admin', 'Petugas', 'Petugas Arsip', 'User'])->default('User');
        });

        // Tabel Dokumen
        Schema::create('dokumen', function (Blueprint $table) {
            $table->id('id_dokumen');
            $table->string('judul');
            $table->text('deskripsi')->nullable();
            $table->string('kategori')->nullable();
            $table->string('tipe_file', 50);
            $table->dateTime('tanggal_upload')->useCurrent();
            $table->string('path_file');
            $table->bigInteger('ukuran_file')->nullable();
            $table->unsignedBigInteger('id_user');
            
            $table->foreign('id_user')->references('id_user')->on('user')->onDelete('cascade');
        });

        // Tabel Barcode
        Schema::create('barcode', function (Blueprint $table) {
            $table->unsignedBigInteger('id_dokumen')->primary();
            $table->string('kode_barcode')->unique();
            
            $table->foreign('id_dokumen')->references('id_dokumen')->on('dokumen')->onDelete('cascade');
        });

        // Tabel Log Aktivitas
        Schema::create('log_aktivitas', function (Blueprint $table) {
            $table->id('id_log');
            $table->unsignedBigInteger('id_user');
            $table->dateTime('waktu_aktivitas')->useCurrent();
            $table->string('jenis_aktivitas');
            $table->text('deskripsi')->nullable();
            
            $table->foreign('id_user')->references('id_user')->on('user')->onDelete('cascade');
        });

        // Tabel Backup
        Schema::create('backup', function (Blueprint $table) {
            $table->id('id_backup');
            $table->unsignedBigInteger('id_user');
            $table->dateTime('tanggal_backup')->useCurrent();
            $table->string('lokasi_file');
            $table->enum('status', ['pending', 'completed', 'failed'])->default('pending');
            $table->bigInteger('ukuran_file')->nullable();
            
            $table->foreign('id_user')->references('id_user')->on('user')->onDelete('cascade');
        });

        // Tabel Sessions (untuk session driver database)
        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sessions');
        Schema::dropIfExists('backup');
        Schema::dropIfExists('log_aktivitas');
        Schema::dropIfExists('barcode');
        Schema::dropIfExists('dokumen');
        Schema::dropIfExists('user');
    }
};
